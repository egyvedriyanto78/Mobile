package pack.helloapps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void GoToActivity2(View view){
        EditText etName = findViewById(R.id.etName);
        EditText etNPM = findViewById(R.id.etNPM);
        EditText etJurusan = findViewById(R.id.etJurusan);
        EditText etFakultas = findViewById(R.id.etFakultas);
        EditText etJK = findViewById(R.id.etJK);
        EditText etAlamat = findViewById(R.id.etAlamat);

        String nama = etName.getText().toString();
        String npm = etNPM.getText().toString();
        String jurusan = etJurusan.getText().toString();
        String fakultas = etFakultas.getText().toString();
        String jk = etJK.getText().toString();
        String alamat = etAlamat.getText().toString();

        Intent goToActivity2 = new Intent(this, Activity2.class);
        goToActivity2.putExtra("nama", nama);
        goToActivity2.putExtra("npm", npm);
        goToActivity2.putExtra("jurusan", jurusan);
        goToActivity2.putExtra("fakultas", fakultas);
        goToActivity2.putExtra("jk", jk);
        goToActivity2.putExtra("alamat", alamat);

        startActivity(goToActivity2);
    }
}