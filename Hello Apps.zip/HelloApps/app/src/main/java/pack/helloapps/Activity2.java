package pack.helloapps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Activity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        Intent intent = getIntent();
        String nama = intent.getStringExtra("nama");
        String npm = intent.getStringExtra("npm");
        String jurusan = intent.getStringExtra("jurusan");
        String fakultas = intent.getStringExtra("fakultas");
        String jk = intent.getStringExtra("jk");
        String alamat = intent.getStringExtra("alamat");

        TextView tvName = findViewById(R.id.tvName);
        TextView tvnpm = findViewById(R.id.tvNPM);
        TextView tvjur = findViewById(R.id.tvJurusan);
        TextView tvfak = findViewById(R.id.tvFakultas);
        TextView tvjk = findViewById(R.id.tvJK);
        TextView tvalamat = findViewById(R.id.tvAlamat);

        tvName.setText(nama);
        tvnpm.setText(npm);
        tvjur.setText(jurusan);
        tvfak.setText(fakultas);
        tvjk.setText(jk);
        tvalamat.setText(alamat);
    }
}